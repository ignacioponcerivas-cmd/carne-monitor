<?php
if ( ! defined( 'ABSPATH' ) ) exit;

define( 'MEATBOX_VERSION', '2.0.1' );
define( 'MEATBOX_DIR', get_template_directory() );
define( 'MEATBOX_URI', get_template_directory_uri() );

function meatbox_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', array( 'height' => 60, 'width' => 200, 'flex-height' => true, 'flex-width' => true ) );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'gallery', 'caption' ) );
	add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
	register_nav_menus( array( 'primary' => 'Menu Principal', 'footer' => 'Menu Footer' ) );
}
add_action( 'after_setup_theme', 'meatbox_setup' );

function meatbox_enqueue_assets() {
	wp_enqueue_style( 'meatbox-fonts', 'https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&display=swap', array(), null );
	wp_enqueue_style( 'meatbox-style', get_stylesheet_uri(), array( 'meatbox-fonts' ), MEATBOX_VERSION );
	wp_enqueue_style( 'meatbox-app', MEATBOX_URI . '/assets/app.css', array( 'meatbox-style' ), MEATBOX_VERSION );
	wp_enqueue_script( 'meatbox-app', MEATBOX_URI . '/assets/app.js', array(), MEATBOX_VERSION, true );

	$upload_dir = wp_upload_dir();
	wp_add_inline_script( 'meatbox-app',
		'window.meatboxData = ' . wp_json_encode( array(
			'apiBase'    => home_url( '/wp-json/wc/store/v1' ),
			'uploadsUrl' => trailingslashit( $upload_dir['baseurl'] ) . 'meatbox/productos/',
			'themeUrl'   => MEATBOX_URI,
			'homeUrl'    => trailingslashit( home_url() ),
		) ) . ';',
		'before'
	);

	add_filter( 'script_loader_tag', 'meatbox_module_tag', 10, 3 );
}
add_action( 'wp_enqueue_scripts', 'meatbox_enqueue_assets' );

function meatbox_module_tag( $tag, $handle, $src ) {
	if ( 'meatbox-app' === $handle ) {
		$tag = '<script type="module" crossorigin src="' . esc_url( $src ) . '"></script>' . "\n";
	}
	return $tag;
}

function meatbox_body_classes( $classes ) {
	$classes[] = 'meatbox-spa';
	return $classes;
}
add_filter( 'body_class', 'meatbox_body_classes' );

add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );

function meatbox_rewrite_rules() {
	add_rewrite_rule( '^planes/?$', 'index.php?meatbox_spa=1', 'top' );
	add_rewrite_rule( '^arma-tu-caja/?$', 'index.php?meatbox_spa=1', 'top' );
	add_rewrite_rule( '^nosotros/?$', 'index.php?meatbox_spa=1', 'top' );
}
add_action( 'init', 'meatbox_rewrite_rules', 11 );

function meatbox_query_vars( $vars ) { $vars[] = 'meatbox_spa'; return $vars; }
add_filter( 'query_vars', 'meatbox_query_vars' );

function meatbox_template_redirect() {
	if ( get_query_var( 'meatbox_spa' ) ) { include MEATBOX_DIR . '/index.php'; exit; }
}
add_action( 'template_redirect', 'meatbox_template_redirect' );

function meatbox_activate() { meatbox_rewrite_rules(); flush_rewrite_rules(); }
add_action( 'after_switch_theme', 'meatbox_activate' );
