<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<footer class="meatbox-footer"><p>&copy; <?php echo date( 'Y' ); ?> MeatBox.</p></footer>
<?php wp_footer(); ?>
</body></html>
