<?php get_header(); ?>
<main class="meatbox-woocommerce"><?php woocommerce_content(); ?></main>
<?php get_footer();
