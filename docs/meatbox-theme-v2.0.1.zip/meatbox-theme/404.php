<?php if ( ! defined( 'ABSPATH' ) ) exit; include get_template_directory() . '/index.php';
